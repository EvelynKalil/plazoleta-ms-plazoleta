package com.plazoletadecomidas.plazoleta_ms_plazoleta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlazoletaMsPlazoletaApplicationTests {

	@Test
	void contextLoads() {
		// Método generado por Spring Boot para probar el arranque del contexto.
	}

}
