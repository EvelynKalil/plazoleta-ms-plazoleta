package com.plazoletadecomidas.plazoleta_ms_plazoleta.domain.model;

public enum OrderStatus {
    PENDIENTE, EN_PREPARACION, LISTO, ENTREGADO, CANCELADO
}