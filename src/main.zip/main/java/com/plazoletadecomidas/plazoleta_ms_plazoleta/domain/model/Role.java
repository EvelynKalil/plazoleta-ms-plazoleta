package com.plazoletadecomidas.plazoleta_ms_plazoleta.domain.model;

public enum Role {
    ADMINISTRADOR,
    PROPIETARIO,
    EMPLEADO,
    CLIENTE
}
