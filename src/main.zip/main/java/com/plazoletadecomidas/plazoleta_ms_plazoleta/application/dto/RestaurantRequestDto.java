package com.plazoletadecomidas.plazoleta_ms_plazoleta.application.dto;

import lombok.Getter;

import javax.validation.constraints.*;
import java.util.UUID;
@Getter
public class RestaurantRequestDto {
    @NotBlank (message = "El campo nombre es obligatorio")
    @Pattern(regexp = "^(?!\\d+$).+", message = "El nombre no puede contener solo números")
    private String name;

    @NotBlank (message = "El campo NIT es obligatorio")
    private String nit;

    @NotBlank (message = "El campo dirección es obligatorio")
    private String address;

    @NotBlank (message = "El campo celular es obligatorio")
    @Pattern(regexp = "^\\+?\\d{1,13}$", message = "El celular debe tener máximo 13 digitos y puede comenzar con +")
    private String phone;

    @NotBlank (message = "El campo UrlLogo es obligatorio")
    private String urlLogo;

    @NotNull (message = "El campo Id Propietario es obligatorio")
    private UUID ownerId;

    public RestaurantRequestDto(String restaurante, String number, String calle, String s, String url, UUID uuid) {
    }

}
